﻿using pogeshi.models.deck.card;
using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Reflection;
using Newtonsoft.Json;

namespace pogeshi.models.deck
{
    /*
     * NOTA PER IL DOCENTE:
     * I costruttori che caricano le carte da file (per quanto implementati parzialmente)
     * non sono funzionanti, in quanto in Java è stata utilizzata una libreria differente (GSON),
     * perciò sono da ritenersi solo come mockups. Anche perchè non sono essenziali per il funzionamento
     * della classe Deck.
     */

    /// <summary>
    /// A <see cref="IDeck"/> implementation.
    /// </summary>
    public class DeckImpl : IDeck
    {
        private static readonly int NUMBER_OF_DECK_CARDS = 10;
        private readonly LinkedList<ICard> cards;

        /// <summary>
        /// Instantiates a standard deck.
        /// </summary>
        public DeckImpl() : this(new StreamReader(new MemoryStream(Properties.Resources.DefaultDeck))) { }

        /// <summary>
        /// Instantiates a new deck from a list of cards.
        /// </summary>
        /// <param name="cards">The cards of the deck</param>
        public DeckImpl(IList<ICard> cards)
        {
            this.cards = new LinkedList<ICard>(cards);
        }

        /// <summary>
        /// Instantiates a new deck from a file.
        /// </summary>
        /// <param name="file">the StreamReader that contains the file that contains the deck</param>
        public DeckImpl(StreamReader file)
        {
            this.cards = new LinkedList<ICard>();
            try
            {
                this.cards.Union(JsonConvert.DeserializeObject<LinkedList<CardImpl>>(file.ReadToEnd()));
            }
            catch (IOException e)
            {
                Console.WriteLine(e.StackTrace);
            }
        }

        /// <inheritdoc />
        public void AddCard(ICard card) => this.cards.AddLast(card);

        /// <inheritdoc />
        public ICard GetCard() => this.cards.Any() ? this.cards.First.Value : null;

        /// <inheritdoc />
        public IList<ICard> GetCards() => new List<ICard>(this.cards);

        /// <inheritdoc />
        public bool IsCardInDeck(ICard card) => this.cards.Contains(card);

        /// <inheritdoc />
        public bool IsDeckFull() => this.cards.Count == NUMBER_OF_DECK_CARDS;

        /// <inheritdoc />
        public ICard PopCard()
        {
            if (!this.cards.Any())
            {
                return null;
            }
            else
            {
                ICard card = this.cards.First.Value;
                this.RemoveCard(this.cards.First.Value);
                return card;
            }
        }

        /// <inheritdoc/>
        public void RemoveCard(ICard card)
        {
            if (this.cards.Contains(card))
            {
                this.cards.Remove(card);
            }
        }

        public override string ToString()
        {
            string val = "Cards: ";
            foreach (var card in this.cards)
            {
                val += card.ToString() + " ";
            }
            return val;
        }
    }
}
