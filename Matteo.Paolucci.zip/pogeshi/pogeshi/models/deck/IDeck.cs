﻿using pogeshi.models.deck.card;
using System;
using System.Collections.Generic;
using System.Text;

namespace pogeshi.models.deck
{
    /// <summary>
    /// Interface representing a deck of cards.
    /// </summary>
    public interface IDeck
    {
        /// <summary>
        /// Pop a card from deck.
        /// </summary>
        /// <returns>the card</returns>
        ICard PopCard();

        /// <summary>
        /// Gets the last card inserted in the deck.
        /// </summary>
        /// <returns>the card</returns>
        ICard GetCard();

        /// <summary>
        /// Gets the cards of the deck.
        /// </summary>
        /// <returns>the cards of the deck</returns>
        IList<ICard> GetCards();

        /// <summary>
        /// Removes the card from the deck.
        /// </summary>
        /// <param name="card">the card to remove</param>
        void RemoveCard(ICard card);

        /// <summary>
        /// Adds the card to the deck.
        /// </summary>
        /// <param name="card">the card to add</param>
        void AddCard(ICard card);

        /// <summary>
        /// Checks if the deck is full.
        /// </summary>
        /// <returns>true, if the deck is full</returns>
        bool IsDeckFull();

        /// <summary>
        /// Checks if the card is in deck.
        /// </summary>
        /// <param name="card">the card to check</param>
        /// <returns>true, if the card is in the deck</returns>
        bool IsCardInDeck(ICard card);
    }
}
