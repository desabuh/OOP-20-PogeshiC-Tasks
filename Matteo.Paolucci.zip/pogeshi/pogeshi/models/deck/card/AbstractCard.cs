﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace pogeshi.models.deck.card
{
    /// <summary>
    /// An abstract card.
    /// </summary>
    public abstract class AbstractCard : ICard
    {
        /// <summary>
        /// The cost of the card.
        /// </summary>
        protected int Cost { private get; set; }

        /// <summary>
        /// The attack of the card.
        /// </summary>
        protected int Attack { private get; set; }

        /// <summary>
        /// The Shield of the card.
        /// </summary>
        protected int Shield { private get; set; }

        /// <summary>
        /// The name of the card.
        /// </summary>
        protected string Name { private get; set; }

        /// <summary>
        /// The image path of the card.
        /// </summary>
        protected string ResourcePath { private get; set; }

        /// <summary>
        /// The description of the card.
        /// </summary>
        protected string Description { private get; set; }

        /// <summary>
        /// An abstract card builder.
        /// </summary>
        /// <typeparam name="T">the type of the builder</typeparam>
        public abstract class Builder<T> where T : Builder<T>
        {
            /// <summary>
            /// The cost of the card.
            /// </summary>
            protected int Cost_ { get; private set; }

            /// <summary>
            /// The attack of the card.
            /// </summary>
            protected int Attack_ { get; private set; }

            /// <summary>
            /// The Shield of the card.
            /// </summary>
            protected int Shield_ { get; private set; }

            /// <summary>
            /// The name of the card.
            /// </summary>
            protected string Name_ { get; private set; }

            /// <summary>
            /// The image path of the card.
            /// </summary>
            protected string ResourcePath_ { get; private set; }

            /// <summary>
            /// The description of the card.
            /// </summary>
            protected string Description_ { get; private set; }

            /// <summary>
            /// Set the name of the card.
            /// </summary>
            /// <param name="name">the name to assign to the card</param>
            /// <returns>this builder</returns>
            public T Name(String name)
            {
                Name_ = name;
                return Self();
            }

            /// <summary>
            /// Set the cost of the card.
            /// </summary>
            /// <param name="cost">the cost to assign to the card</param>
            /// <returns>this builder</returns>
            public T Cost(int cost)
            {
                if (cost < 0)
                {
                    throw new ArgumentException("Cost must be >= 0!");
                }
                Cost_ = cost;
                return Self();
            }

            /// <summary>
            /// Set the resource path of the card image.
            /// </summary>
            /// <param name="path">the path of the card image to assign to the card</param>
            /// <returns>this builder</returns>
            public T ResourcePath(String path)
            {
                ResourcePath_ = path;
                if (!File.Exists(path))
                {
                    throw new FileNotFoundException();
                }
                return Self();
            }

            /// <summary>
            /// Set the description of the card.
            /// </summary>
            /// <param name="description">the description to assign to the card</param>
            /// <returns>this builder</returns>
            public T Description(String description)
            {
                Description_ = description;
                return Self();
            }

            /// <summary>
            /// Set the attack of the card.
            /// </summary>
            /// <param name="attack">the attack to assign to the card</param>
            /// <returns>this builder</returns>
            public T Attack(int attack)
            {
                if (attack < 0)
                {
                    throw new ArgumentException("Attack must be >= 0!");
                }
                Attack_ = attack;
                return Self();
            }

            /// <summary>
            /// Set the shield of the card.
            /// </summary>
            /// <param name="shield">the shield to assign to the card</param>
            /// <returns>this builder</returns>
            public T Shield(int shield)
            {
                if (shield < 0)
                {
                    throw new ArgumentException("Shield must be >= 0!");
                }
                Shield_ = shield;
                return Self();
            }

            /// <summary>
            /// Returns a newly-created Card.
            /// </summary>
            /// <returns>a card</returns>
            public abstract ICard Build();

            /// <summary>
            /// Return this builder to use method chaining with subclasses.
            /// </summary>
            /// <returns>this builder</returns>
            protected abstract T Self();
        }

        /// <inheritdoc />
        public int GetCost() => this.Cost;

        /// <inheritdoc />
        public int GetAttack() => this.Attack;

        /// <inheritdoc />
        public int GetShield() => this.Shield;

        /// <inheritdoc />
        public string GetName() => this.Name;

        /// <inheritdoc />
        public string GetResourcePath() => this.ResourcePath;

        /// <inheritdoc />
        public string GetDescription() => this.Description;

        public override string ToString()
        {
            return "[Name: " + this.Name + ", Description: " + this.Description + ", ResourcePath: " + this.ResourcePath +
                ", Cost: " + this.Cost + ", Attack: " + this.Attack + ", Shield: " + this.Shield + "]";
        }
    }
}
