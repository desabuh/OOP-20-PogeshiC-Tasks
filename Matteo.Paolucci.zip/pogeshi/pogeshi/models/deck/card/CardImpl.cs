﻿using System;
using System.Collections.Generic;
using System.Text;

namespace pogeshi.models.deck.card
{
    /// <summary>
    /// A <see cref="ICard"/> implementation.
    /// </summary>
    /// <inheritdoc />
    public class CardImpl : AbstractCard
    {
        public class Builder : Builder<Builder>
        {
            /// <inheritdoc />
            public override ICard Build()
            {
                if (Description_ is null || ResourcePath_ is null || Name_ is null)
                {
                    throw new ArgumentNullException();
                }
                return new CardImpl
                {
                    Attack = this.Attack_,
                    Description = this.Description_,
                    ResourcePath = this.ResourcePath_,
                    Shield = this.Shield_,
                    Name = this.Name_,
                    Cost = this.Cost_
                };
            }

            /// <inheritdoc />
            protected override Builder Self() => this;
        }

        private CardImpl() { }

        public override bool Equals(object obj)
        {
            return obj is CardImpl impl &&
                   this.GetCost() == impl.GetCost() &&
                   this.GetAttack() == impl.GetAttack() &&
                   this.GetShield() == impl.GetShield() &&
                   this.GetName() == impl.GetName() &&
                   this.GetResourcePath() == impl.GetResourcePath() &&
                   this.GetDescription() == impl.GetDescription();
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(this.GetCost(), this.GetAttack(), this.GetShield(), this.GetName(), this.GetResourcePath(), this.GetDescription());
        }
    }
}
