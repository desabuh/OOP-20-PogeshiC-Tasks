﻿using System;
using System.Collections.Generic;
using System.Text;

namespace pogeshi.models.deck.card
{
    /// <summary>
    /// Interface representing a card of a deck.
    /// </summary>
    public interface ICard
    {
        /// <summary>
        /// Gets the cost.
        /// </summary>
        /// <returns>the cost of this card</returns>
        int GetCost();

        /// <summary>
        /// Gets the attack.
        /// </summary>
        /// <returns>the attack of this card</returns>
        int GetAttack();

        /// <summary>
        /// Gets the shield.
        /// </summary>
        /// <returns>the shield of this card</returns>
        int GetShield();

        /// <summary>
        /// Gets the name.
        /// </summary>
        /// <returns>the name of this card</returns>
        string GetName();

        /// <summary>
        /// Gets the resource path.
        /// </summary>
        /// <returns>the name of this card</returns>
        string GetResourcePath();

        /// <summary>
        /// Gets the description.
        /// </summary>
        /// <returns>the Description of this card</returns>
        string GetDescription();
    }
}
