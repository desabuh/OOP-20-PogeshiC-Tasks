using NUnit.Framework;
using System;
using System.IO;
using System.Collections.Generic;
using pogeshi.models.deck.card;
using pogeshi.models.deck;

namespace TestPogeshi
{
    public class Tests
    {
        private static readonly string dirTaskPogeshi = AppDomain.CurrentDomain.BaseDirectory + ".." + Path.DirectorySeparatorChar 
            + ".." + Path.DirectorySeparatorChar + ".." + Path.DirectorySeparatorChar + ".." + Path.DirectorySeparatorChar + "pogeshi" 
            + Path.DirectorySeparatorChar + "res";

        [Test]
        public void TestCardBuilder()
        {
            Assert.Throws<ArgumentNullException>(() => new CardImpl.Builder()
                                                                   .ResourcePath(dirTaskPogeshi + Path.DirectorySeparatorChar + "img.png")
                                                                   .Build());
            Assert.Throws<FileNotFoundException>(() => new CardImpl.Builder()
                                                                   .Description("a")
                                                                   .Name("b")
                                                                   .ResourcePath("ciao")
                                                                   .Build());
            Assert.Throws<ArgumentException>(() => new CardImpl.Builder()
                                                               .Description("a")
                                                               .Name("b")
                                                               .ResourcePath(dirTaskPogeshi + Path.DirectorySeparatorChar + "img.png")
                                                               .Attack(-1)
                                                               .Build());
        }

        [Test]
        public void TestingEmptyDeck()
        {
            IDeck deck = new DeckImpl(new List<ICard>());
            Assert.IsNull(deck.PopCard());
            Assert.IsNull(deck.GetCard());
            Assert.AreEqual(0, deck.GetCards().Count);
            Assert.AreEqual(deck.GetCards(), new List<ICard>());
        }

        [Test]
        public void TestingDeck()
        {
            IDeck deck = new DeckImpl(new List<ICard>());
            ICard card = new CardImpl.Builder()
                                     .Description("a")
                                     .Name("b")
                                     .ResourcePath(dirTaskPogeshi + Path.DirectorySeparatorChar + "img.png")
                                     .Attack(1)
                                     .Build();
            deck.AddCard(card);
            Assert.IsTrue(deck.IsCardInDeck(card));
            Assert.IsFalse(deck.IsDeckFull());
            deck.RemoveCard(card);
            Assert.IsFalse(deck.IsCardInDeck(card));
        }
    }
}