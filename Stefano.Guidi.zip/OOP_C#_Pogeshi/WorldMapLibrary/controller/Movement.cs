﻿using System.Collections.Generic;
using IPoint2D = models.GameMap.IPoint2D;
using System;

namespace controllers
{


	/// 
	/// <summary>
	/// this enum incapsulate the logic for Movement in 2d coordinates.
	/// 
	/// </summary>
	public sealed class Movement
	{

		private static readonly List<Movement> valueList = new List<Movement>();

		static Movement()
		{
			valueList.Add(new Movement(InnerEnum.UP, p => p.sum(-1,0)));
			valueList.Add(new Movement(InnerEnum.DOWN, p => p.sum(1,0)));
			valueList.Add(new Movement(InnerEnum.LEFT, p => p.sum(0,-1)));
			valueList.Add(new Movement(InnerEnum.RIGTH, p => p.sum(0,1)));
		}

		public enum InnerEnum
		{
			UP,
			DOWN,
			LEFT,
			RIGTH
		}

		public readonly InnerEnum innerEnumValue;

		private Func<IPoint2D, IPoint2D> offsetFunction;

		internal Movement(InnerEnum innerEnum, Func<IPoint2D, IPoint2D> offsetFunction)
		{
			this.offsetFunction = offsetFunction;
			innerEnumValue = innerEnum;
		}

		public IPoint2D getDestFor(IPoint2D point)
		{
			return this.offsetFunction(point);
		}


		public static Movement valueOf(InnerEnum name)
		{
			foreach (Movement enumInstance in Movement.valueList)
			{
				if (enumInstance.innerEnumValue == name)
				{
					return enumInstance;
				}
			}
			throw new System.ArgumentException(name.ToString());
		}
	}

}