﻿namespace models.GameMap
{
	public interface IPoint2D
	{

		/// <summary>
		/// Return value of coordinate {@code X}. </summary>
		/// <returns>  Value of X. </returns>
		int X {get;}

		/// <summary>
		/// Return value of coordinate {@code Y}. </summary>
		/// <returns>  Value of Y. </returns>
		int Y {get;}

		/// <summary>
		/// Set value of coordinate {@code X} and return a new {@code IPoint2D} with new {@code X} coordinate. </summary>
		/// <param name="x">     Value to be set for {@code X}. </param>
		/// <returns>      New {@code IPoint2D}. </returns>
		IPoint2D setX(int x);

		/// <summary>
		/// Set value of coordinate {@code Y} and return a new {@code IPoint2D} with new {@code Y} coordinate. </summary>
		/// <param name="y">     Value to be set for {@code Y}. </param>
		/// <returns>      New {@code IPoint2D}. </returns>
		IPoint2D setY(int y);

		/// <summary>
		/// Sum the x and y values to the {@code X} and {@code Y} coordinates of this {@code IPoint2D}
		/// and return a new {@code Point2D} with new {@code X} and {@code Y} coordinates. </summary>
		/// <param name="x">     x value to add. </param>
		/// <param name="y">     y value to add. </param>
		/// <returns>      New {@code IPoint2D}. </returns>
		IPoint2D sum(int x, int y);

	}

}