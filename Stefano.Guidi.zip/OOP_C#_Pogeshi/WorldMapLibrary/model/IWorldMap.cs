﻿using System.Collections.Generic;
using System; 

 


namespace models.GameMap
{
	
	using Movement = controllers.Movement;

	//NOTA PER IL DOCENTE:
	//Per evitare di riproporre codice relativo ai Character(Enemy o Player) si è scelto di utilizzare le sole posizioni relative al
	//player e all'enemy. Oltre ad evitare di riproporre codice con classi dummy(in quanto consistenti nel lavoro di altri membri) si è scelto 
	//di fare ciò anche per il fatto che le funzionalità 
	//interessanti di WorldMap sono realizzate lavorando sulle posizioni relative alle entità rappresentate più che sulle entità stesse
	// e pertanto questa semplificazione finisce
	//solo per non includere delle operazioni di mapping dei character alle loro relative posizioni e viceversa 

	//La differenza principale nella realizzazione del contratto è il fatto che tutti i metodi che restituivano Character forniscono ora le loro posizioni,
	//mentre il metodo removeEnemy è stato rimosso

	//Si ritiene comunque che questa scelta non influenzi pesantemente la mole di realizzazione e , anzi, riesca a fornire insieme alle altre classi
	//trasposte un sottoinsieme significativo di funzionalità in C# che si aggiri intorno alle 10 ore
	public interface IWorldMap
	{


		/// <summary>
		/// set player data. </summary>
		/// <param name="player"> new player data </param>
		IPoint2D PlayerPosition {set;get;}


		/// <summary>
		/// Interact with nearby enemies. </summary>
		/// <returns> a nullable if no adjacent enemies are founded, otherwise the first occurence of nearby enemy </returns>
		IPoint2D playerInteract();

		/// <summary>
		/// retrieve boss enemy. </summary>
		/// <returns> a nullable if all the enemies are not defeated, otherwise enemy boss instance </returns>
		IPoint2D Boss {get;}

		/// <summary>
		/// retrieve all enemies positions. </summary>
		/// <returns> enemy list </returns>
		IList<IPoint2D> Enemies {get;}

		/// 
		/// <param name="direction"> <seealso cref="Movement"/> as strategy for Movement. </param>
		/// <returns> a <seealso cref="IPoint2D"/> if Movement is valid, otherwise a nullable </returns>
		IPoint2D updatePlayerPosition(Movement direction);
	}

}