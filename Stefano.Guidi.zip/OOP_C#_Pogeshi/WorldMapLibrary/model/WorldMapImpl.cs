﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System;


namespace models.GameMap
{



	using Movement = controllers.Movement;


	public sealed class WorldMap : IWorldMap
	{

		/// <summary>
		/// logic number of row for the map.
		/// </summary>
		public const int NUM_ROW = 9;

		/// <summary>
		/// logic numer of columns for the map.
		/// </summary>
		public const int NUM_COL = 9;


		private IList<IPoint2D> enemies;
		private IPoint2D boss;
		private IPoint2D player;

		public WorldMap()
		{
			this.player = Point2D.setPoint(0,0);

			this.enemies = this.generateCrossPositions(Point2D.setPoint(0, NUM_COL / 2));	

			this.boss = Point2D.setPoint(NUM_ROW / 2, NUM_COL / 2);

		}

		/// <summary>
		/// generate na IPoint2D stream of cross positions from the center of the map to be assigned to enemies.
		/// it performs first a 90 degree rotation for starting point and after that an additional 180 degree
		/// to the 2 resulting points, this is applied by flatting and mapping to the 90 degree starting point
		/// and to the resulting two point by flatting each of these points and mapping them to their 180 degree coordinate </summary>
		/// <param name="start"> point to start the generation from. </param>
		/// <returns> a stream of cross positions </returns>
		private IList<IPoint2D> generateCrossPositions(IPoint2D start)
		{
			return new List<IPoint2D>{start}
				.SelectMany(p => new List<IPoint2D>{p, Point2D.setPoint(start.Y, NUM_ROW - p.X - 1)})
				.SelectMany(p => new List<IPoint2D>{p, Point2D.setPoint(NUM_COL - p.X - 1, NUM_COL - p.Y - 1)})
				.ToList();

		}

		/// <summary>
		/// check wether the adjacent positions from the argument have some enemies. </summary>
		/// <param name="point"> point to check the adjacence </param>
		/// <returns> the first adjacent enemy founded, otherwise nullable</returns>
		private IPoint2D getEnemyIfAdjacent(IPoint2D point)
		{
			return Enumerable.Range(point.X - 1, point.X + 2)
				.SelectMany(x => Enumerable.Range(point.Y - 1, point.Y + 2)
				    .Select(y => Point2D.setPoint(x,y)))
				.SelectMany(p => this.Enemies.Where(ep => ep.Equals(p)))
				.First();
		}

		/// <summary>
		/// check wether the destination is occupied by an enemy. </summary>
		/// <param name="point"> destination point </param>
		/// <returns> true if no collision is detected, otherwise false </returns>
		private bool noCollisionDetected(IPoint2D point)
		{	
			return !(new List<IPoint2D>{point}
				.SelectMany(p => this.enemies.Where(ep => ep.Equals(p))))
				.Any();

		}

		/// <summary>
		/// check wether the destination point is outside of the map dimension. </summary>
		/// <param name="point"> destination point </param>
		/// <returns> true if destination is in bound, otherwise false </returns>
		private bool isPositionInBounds(IPoint2D point)
		{
			return Enumerable.Range(0, NUM_ROW)
				       .SelectMany(x => Enumerable.Range(0, NUM_COL)
					       .Select(y => Point2D.setPoint(x,y)))
				       .Any(p => p.Equals(point));
		}




		public IPoint2D playerInteract()
		{
			return this.getEnemyIfAdjacent(this.player);
		}

		public IPoint2D Boss
		{
			get
			{
				return this.Enemies.Contains(this.boss) ? this.boss : null;
			}
		}

		public IPoint2D PlayerPosition
		{
			get
			{
				return this.player;
			}
			set 
			{
				this.player = value;
			}
		}

		public IList<IPoint2D> Enemies
		{
			get
			{
				return new ReadOnlyCollection<IPoint2D>(this.enemies);
			}
		}

		public IPoint2D updatePlayerPosition(Movement direction)
		{
			return new List<IPoint2D>{this.player}
				.SelectMany(p => new List<IPoint2D>{this.player}
					.Select(point => direction.getDestFor(point)))
				.Where(isPositionInBounds)
				.Where(noCollisionDetected)
				.Select(point =>
					{
						this.player = point;
						return point;
					})
				.DefaultIfEmpty()
				.First();
		}

	}

}