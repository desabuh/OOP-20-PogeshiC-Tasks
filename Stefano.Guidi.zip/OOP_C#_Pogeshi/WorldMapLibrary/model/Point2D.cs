﻿namespace models.GameMap
{
	/// 
	/// <summary>
	/// immutable class to provide basic operation with 2D coordinate points, implements <seealso cref="IPoint2D"/>.
	/// 
	/// </summary>
	public sealed class Point2D : IPoint2D
	{


		private int x;


		private int y;

		/// <summary>
		/// static factory to get a new {@code Point2D} based on its coordinate. </summary>
		/// <param name="x"> </param>
		/// <param name="y"> </param>
		/// <returns> {@code IPoint2D} new {@code IPoint2D} instance  </returns>
		public static IPoint2D setPoint(int x, int y)
		{
			return new Point2D(x, y);
		}

		/// <summary>
		/// static function to provide a new sum-wise IPoint2D. </summary>
		/// <param name="point1"> </param>
		/// <param name="point2"> </param>
		/// <returns> IPoint2D new IPoint2D instance </returns>
		public static IPoint2D sumPoint2d(IPoint2D point1, IPoint2D point2)
		{
			return setPoint(point1.X + point2.X, point1.Y + point2.Y);
		}

		/// <summary>
		/// Set {@code this.X} and {@code this.Y} equals to x and y. </summary>
		/// <param name="x"> </param>
		/// <param name="y"> </param>
		public Point2D(int x, int y)
		{
			this.x = x;
			this.y = y;
		}

		public int X
		{
			get
			{
				return x;
			}
		}

		public int Y
		{
			get
			{
				return y;
			}
		}

		public IPoint2D setX(int x)
		{
			return new Point2D(x, this.y);
		}

		public IPoint2D setY(int y)
		{
			return new Point2D(this.x, y);
		}

		public IPoint2D sum(int x, int y)
		{
			return setPoint(this.X + x, this.Y + y);
		}

		public override int GetHashCode()
		{
			const int prime = 31;
			int result = 1;
			result = prime * result + x;
			result = prime * result + y;
			return result;
		}

		public override bool Equals(object obj)
		{
			if (this == obj)
			{
				return true;
			}
			if (obj == null)
			{
				return false;
			}
			if (this.GetType() != obj.GetType())
			{
				return false;
			}
			Point2D other = (Point2D) obj;
			if (x != other.x)
			{
				return false;
			}
			if (y != other.y)
			{
				return false;
			}
			return true;
		}


		public override string ToString()
		{
			return "Point2D [x=" + x + ", y=" + y + "]";
		}

	}


}