using Microsoft.VisualStudio.TestTools.UnitTesting;

using Point2DImp = models.GameMap.Point2D; 
using Point2D = models.GameMap.IPoint2D; 

using WorldMap = models.GameMap.WorldMap;
using WorldMapImpl = models.GameMap.WorldMap;

using Movement = controllers.Movement;


namespace WorldMapLibraryTest
{
    [TestClass]
    public class UnitTest1
    {
        public const int ENEMIES_NUMBER = 4;

        [TestMethod]
        public void outOfBoundsTest()
        {
            WorldMap worldMap = new WorldMapImpl();
            Assert.AreEqual(ENEMIES_NUMBER, worldMap.Enemies.Count);
            Assert.IsNull(worldMap.updatePlayerPosition(Movement.valueOf(Movement.InnerEnum.LEFT)));
            Assert.IsNotNull(worldMap.updatePlayerPosition(Movement.valueOf(Movement.InnerEnum.RIGTH)));
        }

        [TestMethod]
        public void interactTest() 
        {
            WorldMap worldMap = new WorldMapImpl();
            worldMap.updatePlayerPosition(Movement.valueOf(Movement.InnerEnum.DOWN));
            worldMap.updatePlayerPosition(Movement.valueOf(Movement.InnerEnum.DOWN));
            worldMap.updatePlayerPosition(Movement.valueOf(Movement.InnerEnum.DOWN));
            Assert.IsNull(worldMap.updatePlayerPosition(Movement.valueOf(Movement.InnerEnum.DOWN)));
            Assert.IsNotNull(worldMap.playerInteract());
        }
    }
}
