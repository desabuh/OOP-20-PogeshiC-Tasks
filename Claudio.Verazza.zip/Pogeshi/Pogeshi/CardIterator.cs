﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Pogeshi
{
  public class CardIterator : ICardIterator
  {

    private IEnumerable<ICard> shuffledCards;
    private IEnumerator<ICard> enumerator;
    public CardIterator(IEnumerable<ICard> deck)
    {
      this.shuffledCards = this.Shuffle(deck.ToList());
      this.enumerator = shuffledCards.GetEnumerator();
      this.enumerator.Reset();
      this.enumerator.MoveNext();
    }

    public object Current => enumerator.Current;

    ICard IEnumerator<ICard>.Current => throw new NotImplementedException();

    public void Dispose()
    {
      //Empty on purpose: this item will never be disposed
      //throw new NotImplementedException();
    }

    /**
     Since this iterator is ideally infinite, if it's completed, the Reset method is called, shuffling again the deck and generating a new iterator over it.
     */
    public bool MoveNext()
    {
      if (!enumerator.MoveNext())
      {
        this.Reset();
      }
      return true;
    }

    public void Reset()
    {
      this.shuffledCards = this.Shuffle(shuffledCards.ToList());
      this.enumerator = shuffledCards.GetEnumerator();
      this.enumerator.MoveNext();
    }

    /**
     This is the method used to always retrieve a new card to the hand.
     */
    public ICard SupplyCard()
    {
      ICard next = (ICard) this.Current;
      this.MoveNext();
      return next;
    }

    private List<ICard> Shuffle(List<ICard> list)
    {
      Random r = new Random();
      for(int i = 0; i < list.Count; i++)
      {
        int switchWith = r.Next(0, list.Count);
        ICard switching = list[switchWith];
        list[switchWith] = list[i];
        list[i] = switching;
      }
      return list;
    }
  }
}