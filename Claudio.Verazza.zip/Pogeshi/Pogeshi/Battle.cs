﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pogeshi
{
  public class Battle : IBattle
  {
    /**
     * Since to test the battle some other components are required, they have been implemented as simple dummy classes. These dummies are Character and Card (and the respective interfaces)
     * The specific implementations of character (enemy and player) are not being developed for this snippet. Partly because is not required and would overcomplicate the code, and partly because those implementations belong to another colleague.
     */
    public const int BASE_STARTING_CARDS = 3;
    public const int MAX_CARDS_IN_HAND = 5;
    public const int DECK_SIZE = 8;
    private int playerUnusedCombatMana { get; set; }
    private IBattle.Turn turn = IBattle.Turn.PLAYER;
    private bool hasBeenInitialized = false;
    private bool hasBattleFinished = false;

    private ICharacter player;
    private ICharacter enemy;
    private ICardIterator playerCardsIterator;
    private ICardIterator enemyCardsIterator;


    public Battle()
    {
      player = new Character();
      enemy = new Character(10);
      player.generateRandomDeck(DECK_SIZE);
      enemy.generateRandomDeck(DECK_SIZE);
    }

    public Battle(ICharacter player)
    {
      this.player = player;
      enemy = new Character(10);
      enemy.generateRandomDeck(DECK_SIZE);
    }

    public bool checkBattleEnd()
    {
      if(player.health <= 0 || enemy.health <= 0)
      {
        hasBattleFinished = true;
      }
      return hasBattleFinished;
    }

    public ICharacter currentTurn()
    {
      throw new NotImplementedException();
    }

    public void endTurn()
    {
      if(this.turn == IBattle.Turn.PLAYER)
      {
        this.turn = IBattle.Turn.ENEMY;
      }
      else
      {
        this.turn = IBattle.Turn.PLAYER;
        player.mana++;
        playerUnusedCombatMana = player.mana;
      }
      this.drawCard();
    }

    public ICharacter getEnemy()
    {
      return this.enemy;
    }

    public ICharacter getPlayer()
    {
      return this.player;
    }

    public int getPlayerUnusedCombatMana()
    {
      return playerUnusedCombatMana;
    }

    public bool hasPlayerWon()
    {
      if (!hasBattleFinished)
      {
        throw new InvalidOperationException("The battle has not ended yet");
      }
      return player.health > 0;
    }

    public void initializeCharacters()
    {
      if (hasBeenInitialized)
      {
        throw new InvalidOperationException("Both opponents have already been initialized");
      }
      playerCardsIterator = new CardIterator(player.getCards());
      enemyCardsIterator = new CardIterator(enemy.getCards());

      for (int i = 0; i < BASE_STARTING_CARDS; i++)
      {
        player.addCardToHand(playerCardsIterator.SupplyCard());
        enemy.addCardToHand(enemyCardsIterator.SupplyCard());
      }
      playerUnusedCombatMana = player.mana;
      hasBeenInitialized = true;
    }
    public bool playCard(int index)
    {
      this.checkBattleStatus();
      ICard played;
      if(turn == IBattle.Turn.PLAYER)
      {
        if (index >= player.getHand().Count || index < 0)
        {
          throw new ArgumentOutOfRangeException("Tried to play a card that is not in the hand");
        }
        played = player.getHand()[index];
        if (played.getCost() <= playerUnusedCombatMana)
        {
          playerUnusedCombatMana -= played.getCost();
          inflictDamage(ref player, ref enemy, played);
        }
        else
        {
          return false;
        }
      }
      else
      {
        played = enemy.getHand()[index];
        inflictDamage(ref enemy, ref player, played);
      }
      return true;
    }

    public void reset()
    {
      throw new NotImplementedException();
    }

    public void setPlayer(ICharacter player)
    {
      this.player = player;
    }

    private void checkBattleStatus()
    {
      if (hasBattleFinished)
      {
        throw new InvalidOperationException("You cannot perform any more actions because the battle already ended.");
      }
      if (!hasBeenInitialized)
      {
        throw new InvalidOperationException("The opponents have not been initialized.");
      }
    }

    private void inflictDamage(ref ICharacter attacker, ref ICharacter target, ICard c)
    {
      int damage = c.getAttack();
      if(target.shield > damage)
      {
        target.shield -= target.shield - damage;
        damage = 0;
      }
      else if(target.shield > 0)
      {
        damage -= target.shield;
        target.shield = 0;
      }
      target.health -= damage;
      if(c.getShield() > 0)
      {
        attacker.shield = attacker.shield + c.getShield();
      }
      attacker.removeCardFromHand(c);
    }

    private void drawCard()
    {
      if(turn == IBattle.Turn.PLAYER)
      {
        if(player.getHand().Count < MAX_CARDS_IN_HAND)
        {
          player.addCardToHand(playerCardsIterator.SupplyCard());
        }
      }
      else
      {
        if (enemy.getHand().Count < MAX_CARDS_IN_HAND)
        {
          enemy.addCardToHand(enemyCardsIterator.SupplyCard());
        }
      }
    }

  }
}
