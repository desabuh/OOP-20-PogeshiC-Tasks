﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pogeshi
{
  public interface ICardIterator : IEnumerator<ICard>
  {
    public ICard SupplyCard();
  }
}
