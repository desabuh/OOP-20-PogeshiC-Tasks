﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pogeshi
{
  public interface ICard
  {
    int getCost();
    int getAttack();
    int getShield();
  }
}
