﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pogeshi
{
  public interface ICharacter
  {
    int health { get; set; }
    int shield { get; set; }
    int mana { get; set; }

    List<ICard> getCards();
    void addCard(ICard c);
    void removeCard(ICard c);
    void addCardToHand(ICard c);
    void removeCardFromHand(ICard c);
    List<ICard> getHand();
    void generateRandomDeck(int numberOfCards);
  }
}
