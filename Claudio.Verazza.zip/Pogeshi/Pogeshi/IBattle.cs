﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pogeshi
{
  public interface IBattle
  {
    void endTurn();
    bool checkBattleEnd();
    ICharacter currentTurn();
    bool playCard(int index);
    ICharacter getPlayer();
    ICharacter getEnemy();
    void initializeCharacters();
    int getPlayerUnusedCombatMana();
    void setPlayer(ICharacter player);
    enum Turn
    {
      PLAYER,
      ENEMY
    }
    bool hasPlayerWon();
    void reset();
  }
}
