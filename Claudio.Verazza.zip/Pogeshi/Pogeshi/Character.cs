﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pogeshi
{
  public class Character : ICharacter
  {
    private List<ICard> deck;
    private List<ICard> hand = new List<ICard>();

    public int health { get; set; }
    public int shield { get; set; }
    public int mana { get; set; }

    public Character()
    {
      this.health = 250;
      this.shield = 0;
      this.mana = 1;
      deck = new List<ICard>();
    }
    public Character(List<ICard> deck)
    {
      this.health = 250;
      this.shield = 0;
      this.deck = deck;
      this.mana = 1;
    }

    public Character(int health)
    {
      this.health = health;
      this.shield = 0;
      this.deck = new List<ICard>();
      this.mana = 1;
    }
    public List<ICard> getCards()
    {
      return this.deck;
    }

    public void addCard(ICard c)
    {
      this.deck.Add(c);
    }

    public void removeCard(ICard c)
    {
      this.deck.Remove(c);
    }

    public void addCardToHand(ICard c)
    {
      this.hand.Add(c);
    }

    public void removeCardFromHand(ICard c)
    {
      this.hand.Remove(c);
    }

    public List<ICard> getHand()
    {
      return this.hand;
    }

    public void generateRandomDeck(int numberOfCards)
    {
      Random r = new Random();
      int cost;
      for(int i = 0; i < numberOfCards; i++)
      {
        cost = r.Next(0, 10);
        deck.Add(new Card(cost, cost, cost));
      }
    }

  }
}
