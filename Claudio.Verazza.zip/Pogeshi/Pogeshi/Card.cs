﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pogeshi
{
  public class Card : ICard
  {
    private int cost { get; set; }
    private int attack { get; set; }
    private int shield { get; set; }

    public Card(int cost, int attack, int shield)
    {
      this.cost = cost;
      this.attack = attack;
      this.shield = shield;
    }

    public int getAttack()
    {
      return cost;
    }

    public int getCost()
    {
      return attack;
    }

    public int getShield()
    {
      return shield;
    }
  }
}
