using Microsoft.VisualStudio.TestTools.UnitTesting;
using Pogeshi;
using System;

namespace battletest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
		[ExpectedException(typeof(InvalidOperationException), "The opponents have not been initialized.")]
        public void UninitializedBattleTest()
        {
			IBattle battle = new Battle();
			battle.playCard(0);
        }
		
		[TestMethod]
		public void PlayerPlayingCardTest()
		{
			IBattle battle;
			ICharacter player = new Character();
			for(int i = 1; i < 10; i++)
			{
				player.addCard(new Card(i, i, i));
			}
			battle = new Battle(player);
			battle.initializeCharacters();
			ICard playing = battle.getPlayer().getHand()[0];
			int startingEnemyHealth = battle.getEnemy().health;
			int damage = playing.getAttack();
			int shield = playing.getShield();
			while(!battle.playCard(0))
			{
				battle.endTurn();
				battle.endTurn();
			}
			Assert.AreEqual(startingEnemyHealth - damage, battle.getEnemy().health);
			Assert.AreEqual(shield, battle.getPlayer().shield);
		}
		
		[TestMethod]
		public void TestPlayerHand()
		{
			IBattle battle = new Battle();
			battle.initializeCharacters();
			for(int i = 0; i < 10; i++)
			{
				battle.endTurn();
			}
			Assert.AreEqual(5, battle.getPlayer().getHand().Count);
			while(!battle.playCard(0))
			{
				battle.endTurn();
				battle.endTurn();
			}
			Assert.AreEqual(4, battle.getPlayer().getHand().Count);
		}
		
		[TestMethod]
		public void PlayerWinTest()
		{
			IBattle battle = new Battle();
			battle.initializeCharacters();
			while (!battle.checkBattleEnd()) {
				battle.playCard(0);
				battle.endTurn();
				battle.endTurn();
			}
			Assert.IsTrue(battle.hasPlayerWon());
		}
    }
	
	
}
