using pogeshi.model.character;
using pogeshi.model.account;

using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;

namespace pogeshi
{
    [TestClass]
    public class ClassTest
    {
        /// <summary>Test if creating an instance of PlayerImp work as intended.</summary>
        [TestMethod]
        public void TestPlayerCreate()
        {
            IPlayer player = new PlayerImp(new List<int>() {1, 2, 3, 4, 5}, new Point2DImp(0, 0));

            foreach (int i in new List<int>() {1, 2, 3, 4, 5})
            {
                /// <summary>Test if all the values of the Deck are the right ones.</summary>
                Assert.IsTrue(player.GetDeck().Contains(i));
            }

            foreach (int i in new List<int>())
            {
                /// <summary>Test if all the values of the Hand are the right ones.</summary>
                Assert.IsTrue(player.GetHand().Contains(i));
            }

            /// <summary>Test if the value of the Health is the right one.</summary>
            Assert.AreEqual(100, player.GetHealth());

            /// <summary>Test if the value of the Mana is the right one.</summary>
            Assert.AreEqual(1, player.GetMana());

            /// <summary>Test if the value of the Position is the right one.</summary>
            Assert.IsTrue(player.GetPosition().Equals(new Point2DImp(0, 0)));

            /// <summary>Test if the value of the Shield is the right one.</summary>
            Assert.AreEqual(0, player.GetShield());
            
        }

        /// <summary>Test if the Setters of PlayerImp works as intended.</summary>
        [TestMethod]
        public void TestPlayerSetters()
        {
            IPlayer player = new PlayerImp(new List<int>() {1, 2, 3, 4, 5}, new Point2DImp(0, 0));
            
            int health = player.GetHealth();
            player.SetHealth(10);
            /// <summary>Test if calling SetHealth actually change the Health value</summary>
            Assert.AreEqual(10, player.GetHealth());
            Assert.AreNotEqual(health, player.GetHealth());

            int mana = player.GetMana();
            player.SetMana(10);
            /// <summary>Test if calling SetMana actually change the Mana value</summary>
            Assert.AreEqual(10, player.GetMana());
            Assert.AreNotEqual(mana, player.GetMana());

            int shield = player.GetShield();
            player.SetShield(10);
            /// <summary>Test if calling SetShield actually change the Shield value</summary>
            Assert.AreEqual(10, player.GetShield());
            Assert.AreNotEqual(shield, player.GetShield());

            IPoint2D position = player.GetPosition();
            player.SetPosition(new Point2DImp(10, 10));
            /// <summary>Test if calling SetPosition actually change the Position value</summary>
            Assert.IsTrue(player.GetPosition().Equals(new Point2DImp(10, 10)));
            Assert.IsFalse(player.GetPosition().Equals(new Point2DImp(0, 0)));

            int size = player.GetDeck().Count;
            player.GetDeck().Add(6);
            /// <summary>Test if calling GetDeck.Add actually add an element to the Deck</summary>
            Assert.IsTrue(player.GetDeck().Contains(6));
            Assert.IsTrue(player.GetDeck().Count != size);

            size = player.GetHand().Count;
            player.GetHand().Add(6);
            /// <summary>Test if calling GetHand.Add actually add an element to the Hand</summary>
            Assert.IsTrue(player.GetHand().Contains(6));
            Assert.IsTrue(player.GetHand().Count != size);
        }

        /// <summary>Test if Account actually load all the data.</summary>
        [TestMethod]
        public void TestAccountLoadData()
        {
            IAccount account = new AccountImp();

            foreach (int value in new List<int>() {1, 2, 3, 4, 5})
            {
                /// <summary>Test if the Deck is loaded with default value.</summary>
                Assert.IsTrue(account.GetDeck().Contains(1));

                /// <summary>Test if the RemaingCards are loaded with default value.</summary>
                Assert.IsTrue(account.GetRemainingCards().Contains(1));
            }

            /// <summary>Test if the number of Wins is setted to the default one.</summary>
            Assert.AreEqual(0, account.GetStatistics().GetWins());

            /// <summary>Test if the number of Loses is setted to the default one.</summary>
            Assert.AreEqual(0, account.GetStatistics().GetLoses());

            /// <summary>Test if the number of UnlockedCards is setted to the default one.</summary>
            Assert.AreEqual(10, account.GetStatistics().GetUnlockedCards());

        }

        /// <summary>Testing if adding and removing a card actually remove and add it.</summary>
        [TestMethod]
        public void TestAddAndRemoveCard()
        {
            IAccount account = new AccountImp();

            int sizeDeck = account.GetDeck().Count;
            int sizeRemaingCards = account.GetRemainingCards().Count;
            account.AddCardToDeck(1);

            /// <summary>Test if the size of the Deck actually increased by 1.</summary>
            Assert.IsTrue(account.GetDeck().Count == sizeDeck + 1);

            /// <summary>Test if the size of the RemainingCards actually decreased by 1.</summary>
            Assert.IsTrue(account.GetRemainingCards().Count == sizeRemaingCards - 1);

            sizeDeck = account.GetDeck().Count;
            sizeRemaingCards = account.GetRemainingCards().Count;
            account.RemoveCardFromDeck(1);

            /// <summary>Test if the size of the Deck actually decreased by 1.</summary>
            Assert.IsTrue(account.GetDeck().Count == sizeDeck - 1);

            /// <summary>Test if the size of the RemainingCards actually increased by 1.</summary>
            Assert.IsTrue(account.GetRemainingCards().Count == sizeRemaingCards + 1);

        }
    }
}