using System;

namespace pogeshi.model.account.fileManager
{
    public interface IFileManager<TData>
    {

		/// <summary>
		/// Save the {@code T obj} on file as Json. </summary>
		/// <param name="obj">   {@code obj} to save on file. </param>
        void Save(TData obj);

        /// <summary>
		/// Load a {@code typeOfT obj} from file and return it. </summary>
		/// <param name="typeOfT">       The type of {@code obj} to be loaded. </param>
		/// <returns>              The {@code obj} loaded from file. </returns>
		/// <exception cref="IOException">  Throw IOExeption if file doesn't exist </exception>

        TData Load(Type typeOfT);

		/// <summary>
		/// Delete file.
		/// </summary>
        void DeleteSaves();

		/// <summary>
		/// Return if file exist. </summary>
		/// <returns>  {@code Boolean} for file exist. </returns>
        bool FileExist();

    }
}