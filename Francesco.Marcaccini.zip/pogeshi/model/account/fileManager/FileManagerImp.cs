using System.IO;
using System;
using pogeshi.model.account.gson;

namespace pogeshi.model.account.fileManager
{
    public class FileManagerImp<TData> : IFileManager<TData>
    {

        private string path;
        private Gson gson;

		/// <summary>
		/// Initialize the {@code file} with his path. </summary>
		/// <param name="path">  Path of the file. </param>
        public FileManagerImp(String path)
        {
            this.path = path;
            gson = new GsonBuilder().SetPrettyPrinting().Create();
        }

		/// <summary>
		/// Check if file exist, in case of {@code false} create the file.
		/// Save the passed {@code T obj} on the Json file.
		/// </summary>
        public void Save(TData obj)
        {
            try
            {
                FileStream writer;
                if (!FileExist())
                {
                    writer = File.Create(path);
                } else
                {
                    writer = File.OpenWrite(path);
                }
                gson.ToJson(obj, writer);
                writer.Close();
            } catch (Exception e)
            {
                Console.WriteLine(e.StackTrace);
            }
        }

		/// <summary>
		/// Check if file exist, in case of {@code true} try to load the data as {@code typeOfT} from the file
		/// and return it as {@code T}.
		/// If file exist is {@code false} throw IOExeption.
		/// </summary>
        public TData Load(Type typeOfT)
        {
            if (FileExist())
            {
                try
                {
                    FileStream reader = File.OpenRead(path);
                    TData cards = (TData)gson.FromJson(reader, typeOfT);
                    reader.Close();
                    return cards;
                } catch (Exception e)
                {
                    Console.WriteLine(e.StackTrace);
                    throw new Exception();
                }
            } else
            {
                throw new IOException("File don't exist");
            }
        }

		/// <summary>
		/// Delete the {@code file} and check if the operation succeeded.
		/// </summary>
        public void DeleteSaves()
        {
            try
            {
                File.Delete(path);
            } catch(Exception e)
            {
                Console.WriteLine(e.StackTrace);
            }
        }

		/// <summary>
		/// Return {@code true} if file exist, {@code false} otherwise.
		/// </summary>
        public bool FileExist()
        {
            return File.Exists(path);
        }

    }
}