using System.Collections.Generic;

namespace pogeshi.model.account
{
    public interface IAccount
    {
		/// <summary>
		/// Return the {@code deck} of the {@code Account}. </summary>
		/// <returns>  Value of {@code Deck}. </returns>
        List<int> GetDeck();

		/// <summary>
		/// Return the {@code List<Crad>} of the cards not in the deck of the {@code Account}. </summary>
		/// <returns>  {@code List<Card>} of {@code remaining cards}. </returns>
        List<int> GetRemainingCards();

		/// <summary>
		/// Return the {@code statistics} of the {@code Account}. </summary>
		/// <returns>  {@code obj IStatistics}. </returns>
        IStatistics GetStatistics();

        /// <summary>
		/// Update the number of wins and add a new card to the {@code remaining cards}. </summary>
        /// <exception cref="IOException">      Throw an IOExeption in case the ListOfCards.json default file is missing or corrupted. </exception>
        void Win();

		/// <summary>
		/// Update the number of loses.
		/// </summary>
        void Lose();

		/// <summary>
		/// Add a card to the {@code deck} and remove it from the {@code remaining cards}. </summary>
		/// <param name="card">  {@code obj card} to be added to the {@code deck} and removed from the {@code remaining cards}. </param>
        void AddCardToDeck(int card);

		/// <summary>
		/// Remove a card from the {@code deck} and add it to the {@code remaining cards}. </summary>
		/// <param name="card">  {@code obj card} to be removed from the {@code deck} and added to the {@code remaining cards}. </param>
        void RemoveCardFromDeck(int card);

		/// <summary>
		/// Save all {@code Account} data on file.
		/// </summary>
        void Save();

		/// <summary>
		/// Reset all {@code Account} data on file.
		/// </summary>
        void DeleteSaves();

		/// <summary>
		/// Load all saves.
		/// </summary>
        void LoadSaves();

    }
}