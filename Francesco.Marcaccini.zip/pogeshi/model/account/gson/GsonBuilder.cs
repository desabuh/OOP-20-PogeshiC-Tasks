namespace pogeshi.model.account.gson
{
    ///Dummy class
    public class GsonBuilder
    {
        public GsonBuilder()
        {

        }

        public GsonBuilder SetPrettyPrinting()
        {
            return this;
        }

        public Gson Create()
        {
            return new Gson();
        }

    }
}