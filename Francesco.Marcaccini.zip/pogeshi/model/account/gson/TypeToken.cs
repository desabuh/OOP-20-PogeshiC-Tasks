using System;

namespace pogeshi.model.account.gson
{
    ///Dummy class
    public class TypeToken<TType>
    {
        Type type;

        public TypeToken()
        {
            this.type = typeof(TType);
        }

        public new Type GetType()
        {
            return this.type;
        }
    }
}