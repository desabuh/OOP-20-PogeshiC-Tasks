using System.IO;
using System;
using System.Collections.Generic;

namespace pogeshi.model.account.gson
{
    ///Dummy class
    public class Gson
    {
        public Gson()
        {
            
        }

        public void ToJson(object src, FileStream writer)
        {

        }

        public object FromJson(FileStream reader, Type type)
        {
            if(type == new List<int>().GetType())
            {
                return new List<int>() {1, 2, 3, 4, 5};
            } else if(type == new StatisticsImp().GetType())
            {
                return new StatisticsImp();
            } else
            {
                return null;
            }
        }

    }
}