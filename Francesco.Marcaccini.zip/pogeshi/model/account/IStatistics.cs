namespace pogeshi.model.account
{
    public interface IStatistics
    {
		/// <summary>
		/// Return the number of games won by the {@code Account}. </summary>
		/// <returns>  Value of {@code wins}. </returns>
        int GetWins();

		/// <summary>
		/// Return the number of games lost by the {@code Account}. </summary>
		/// <returns>  Value of {@code loses}. </returns>
        int GetLoses();

		/// <summary>
		/// Return the number of different cards unlocked by the {@code Account}. </summary>
		/// <returns>  Value of {@code different cards unlocked}. </returns>
        int GetUnlockedCards();

        /// <summary>
		/// Update the number of {@code wins} and depending on a {@code boolean} update the number of {@code different cards unlocked}.
		/// <para>
		/// if {@code duplicate card} == {@code true},
		/// then {@code different cards unlocked} remain the same.<br>
		/// if {@code duplicate card} == {@code false},
		/// then {@code different cards unlocked} get updated.
		/// </para> </summary>
		/// <param name="duplicateCard"> {@code boolean} representing if the {@code Card} is a duplicate. </param>
        void UpdateOnWin(bool duplicateCard);

		/// <summary>
		/// Update the number of {@code loses}.
		/// </summary>
        void UpdateOnLose();

    }
}
