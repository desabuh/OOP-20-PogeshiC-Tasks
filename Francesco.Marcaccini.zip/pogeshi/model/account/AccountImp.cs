using System.Collections.Generic;
using System.IO;
using System;
using pogeshi.model.account.fileManager;
using pogeshi.model.account.gson;

namespace pogeshi.model.account
{
    public class AccountImp : IAccount
    {
        private List<int> deck;     //Using Deck as a List<int> to make it easier.
        private List<int> remainingCards;       //Using Card as an int to make it easier.
        private IStatistics statistics;
        private static string SAVES_PATH = "saves" + Path.DirectorySeparatorChar;
        private static Type LINKED_LIST_TYPE = new TypeToken<List<int>>() { }.GetType();
        private FileManagerImp<List<int>> fileDeck;
        private FileManagerImp<List<int>> fileRemainingCards;
        private FileManagerImp<IStatistics> fileStatistics;
        private Random random;

		/// <summary>
		/// Load default saves if existing or create default ones.
		/// </summary>
        public AccountImp()
        {
            random = new Random();
            this.fileDeck = new FileManagerImp<List<int>>(SAVES_PATH + "Deck.json");
            this.fileRemainingCards = new FileManagerImp<List<int>>(SAVES_PATH + "RemainingCards.json");
            this.fileStatistics = new FileManagerImp<IStatistics>(SAVES_PATH + "Statistics.json");
            LoadSaves();
        }

		/// <summary>
		/// Return the value of {@code deck}.
		/// </summary>
        public List<int> GetDeck()
        {
            return this.deck;
        }

		/// <summary>
		/// Return a {@code List<Card>} of the {@code remaining cards}.
		/// </summary>
        public List<int> GetRemainingCards()
        {
            return this.remainingCards;
        }

		/// <summary>
		/// Return a {@code obj statistics} of the statistics of the {@code Account}.
		/// </summary>
        public IStatistics GetStatistics()
        {
            return this.statistics;
        }

		/// <summary>
		/// Load all the {@code cards} from file and then select one at random.
		/// After checking if the {@code deck} or the {@code remaining cards} already have
		/// the selected card, the card get added to the {@code remaining cards} and the
		/// {@code statistics} get updated.
		/// </summary>
        public void Win()
        {
            try
            {
                List<int> allCards = LoadDefaultData("ListOfCards.json");
                int card = allCards[random.Next(allCards.Count)];
                if (this.deck.Contains(card) || this.remainingCards.Contains(card))
                {
                    this.statistics.UpdateOnWin(true);
                } else
                {
                    this.statistics.UpdateOnWin(false);
                }
                this.remainingCards.Add(card);
                this.fileStatistics.Save(this.statistics);
                this.fileRemainingCards.Save(this.remainingCards);
            } catch(IOException e)
            {
                throw new IOException("ListOfCards.json is missing");
            }
        }

		/// <summary>
		/// Update the loses of the {@code statistics}.
		/// </summary>
        public void Lose()
        {
            this.statistics.UpdateOnLose();
            this.fileStatistics.Save(this.statistics);
        }

		/// <summary>
		/// Add {@code card} to the {@code deck},
		/// and remove it from the {@code remaining cards}.
		/// </summary>
        public void AddCardToDeck(int card)
        {
            if (this.remainingCards.Contains(card) && this.deck.Count <= 10)
            {
                this.remainingCards.Remove(card);
                this.deck.Add(card);
            }
        }

	    /// <summary>
		/// Remove {@code card} from the {@code deck},
		/// and add it in the {@code deck}.
		/// </summary>
        public void RemoveCardFromDeck(int card)
        {
            if (this.deck.Contains(card))
            {
                this.deck.Remove(card);
                this.remainingCards.Add(card);
            }
        }

		/// <summary>
		/// Save the {@code deck} and the {@code remaining cards} on file.
		/// </summary>
        public void Save()
        {
            this.fileDeck.Save(this.deck);
            this.fileRemainingCards.Save(this.remainingCards);
        }

		/// <summary>
		/// Overwrite all saves with the default ones.
		/// </summary>
        public void DeleteSaves()
        {
            try
            {
                this.fileDeck.Save(LoadDefaultData("DefaultDeck.json"));
                this.deck = this.fileDeck.Load(LINKED_LIST_TYPE);
                this.fileRemainingCards.Save(new List<int>());
                this.remainingCards = this.fileRemainingCards.Load(LINKED_LIST_TYPE);
                this.fileStatistics.Save(new StatisticsImp(0, 0, this.deck.Count));
                this.statistics = this.fileStatistics.Load(typeof(StatisticsImp));
            } catch (IOException e)
            {
                Console.WriteLine(e.StackTrace);
            }
        }

		/// <summary>
		/// Load all saves and overwrite the current data.
		/// </summary>
        public void LoadSaves()
        {
            if (!Directory.Exists(SAVES_PATH))
            {
                try
                {
                    Directory.CreateDirectory(SAVES_PATH);
                } catch(Exception e)
                {
                    throw new IOException("Could not create the directory.");
                }
            }
            try
            {
                if (!this.fileDeck.FileExist())
                {
                    this.fileDeck.Save(LoadDefaultData("DefaultDeck.json"));
                }
                this.deck = this.fileDeck.Load(LINKED_LIST_TYPE);
                if (!this.fileRemainingCards.FileExist())
                {
                    this.fileRemainingCards.Save(new List<int>());
                }
                this.remainingCards = this.fileRemainingCards.Load(LINKED_LIST_TYPE);
                if (!fileStatistics.FileExist())
                {
                    this.fileStatistics.Save(new StatisticsImp(0, 0, 10));
                }
                this.statistics = fileStatistics.Load(typeof(StatisticsImp));
            } catch (IOException e)
            {
                Console.WriteLine(e.StackTrace);
            }
        }

        private List<int> LoadDefaultData(string fileName)
        {
            try
            {
                FileStream reader = File.OpenRead("json" + Path.DirectorySeparatorChar + fileName);
                Gson gson = new GsonBuilder().SetPrettyPrinting().Create();
                List<int> result = (List<int>)gson.FromJson(reader, LINKED_LIST_TYPE);
                reader.Close();
                return result;
            } catch (IOException e)
            {
                throw new IOException("Error while closing reader.");
            }
        }
    }
}