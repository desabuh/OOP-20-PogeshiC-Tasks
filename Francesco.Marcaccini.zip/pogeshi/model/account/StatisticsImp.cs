namespace pogeshi.model.account
{
    public class StatisticsImp : IStatistics
    {
        private int wins;
        private int loses;
        private int differentCardsUnlocked;

        /// <summary>
		/// Constructor with optional parameters. </summary>
		/// <param name="wins">                      The {@code wins} of the {@code Account}. </param>
		/// <param name="loses">                     The {@code loses} of the {@code Account}. </param>
		/// <param name="differentCardsUnlocked">    The {@code differentCardsUnlocked} by the {@code Account}. </param>
        public StatisticsImp(int wins = 0, int loses = 0, int differentCardsUnlocked = 10)
        {
            this.wins = wins;
            this.loses = loses;
            this.differentCardsUnlocked = differentCardsUnlocked;
        }

		/// <summary>
		/// Return the value of {@code wins}.
		/// </summary>
        public int GetWins()
        {
            return this.wins;
        }

		/// <summary>
		/// Return the value of {@code loses}.
		/// </summary>
        public int GetLoses()
        {
            return this.loses;
        }

		/// <summary>
		/// Return the value of {@code differentCardsUnlocked}.
		/// </summary>
        public int GetUnlockedCards()
        {
            return this.differentCardsUnlocked;
        }

		/// <summary>
		/// Increment the number of {@code wins}, and
		/// if {@code duplicateCard} == {@code true} then Increment the number of {@code differentCardsUnlocked},
		/// otherwise if {@code duplicateCard} == {@code false} do nothing.
		/// </summary>
        public void UpdateOnWin(bool duplicateCard)
        {
            this.wins += 1;
            if (!duplicateCard)
            {
                this.differentCardsUnlocked += 1;
            }
        }

		/// <summary>
		/// Increment the number of {@code loses}.
		/// </summary>
        public void UpdateOnLose()
        {
            this.loses += 1;
        }

    }
}
