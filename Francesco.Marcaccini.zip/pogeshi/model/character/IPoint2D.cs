namespace pogeshi.model.character
{
    public interface IPoint2D
    {

		/// <summary>
		/// Return value of coordinate {@code X}. </summary>
		/// <returns>  Value of X. </returns>
        int GetX();

		/// <summary>
		/// Return value of coordinate {@code Y}. </summary>
		/// <returns>  Value of Y. </returns>
        int GetY();

		/// <summary>
		/// Set value of coordinate {@code X} and return a new {@code Point2D} with new {@code X} coordinate. </summary>
		/// <param name="x">     Value to be set for {@code X}. </param>
		/// <returns>      New {@code Point2D}. </returns>
        IPoint2D SetX(int x);

		/// <summary>
		/// Set value of coordinate {@code Y} and return a new {@code Point2D} with new {@code Y} coordinate. </summary>
		/// <param name="y">     Value to be set for {@code Y}. </param>
		/// <returns>      New {@code Point2D}. </returns>
        IPoint2D SetY(int y);

		/// <summary>
		/// Sum the x and y values to the {@code X} and {@code Y} coordinates of this {@code Point2D}
		/// and return a new {@code Point2D} with new {@code X} and {@code Y} coordinates. </summary>
		/// <param name="x">     x value to add. </param>
		/// <param name="y">     y value to add. </param>
		/// <returns>      New {@code Point2D}. </returns>
        IPoint2D Sum(int x, int y);

    }
}