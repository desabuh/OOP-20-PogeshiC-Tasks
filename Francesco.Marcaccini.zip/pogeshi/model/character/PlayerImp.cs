using System.Collections.Generic;

namespace pogeshi.model.character
{
    public class PlayerImp : CharacterImp, IPlayer
    {

        private int mana;
        private List<int> hand;     //Using Hand as a List<int> to make it easier.
        private readonly int maxMana = 10;

        /// <summary>
		/// Constructor with custom and optional parameters. </summary>
		/// <param name="deck">      The {@code deck} of the {@code player}. </param>
		/// <param name="health">    The {@code health} of the {@code player}. </param>
		/// <param name="shield">    The {@code shield} of the {@code player}. </param>
		/// <param name="mana">      The {@code mana} of the {@code player}. </param>
		/// <param name="position">  The {@code position} of the {@code player}. </param>
        public PlayerImp(List<int> deck, IPoint2D position, int health = 100, int shield = 0, int mana = 1) : base(health, position, deck, shield)
        {
            SetMana(mana);
            this.hand = new List<int>();
        }

		/// <summary>
		/// Set the {@code position} equal to the passed position.
		/// </summary>
        public new void SetPosition(IPoint2D destination)
        {
            base.SetPosition(destination);
        }

		/// <summary>
		/// Return the value of the {@code mana}.
		/// </summary>
        public int GetMana()
        {
            return this.mana;
        }

		/// <summary>
        /// Set the {@code mana} equals to the passed value.
		/// </summary>
        public void SetMana(int value)
        {
            if (!(value < 0 || value > this.maxMana))
            {
                this.mana = value;
            }
        }

		/// <summary>
		/// Return the value of the {@code hand}.
		/// </summary>
        public List<int> GetHand()
        {
            return this.hand;
        }

    }
}
