using System.Collections.Generic;

namespace pogeshi.model.character
{
    public interface IPlayer : ICharacter
    {

		/// <summary>
		/// Set the {@code position} of the player. </summary>
		/// <param name="destination">   {@code Point2D destination} of the new position. </param>
        void SetPosition(IPoint2D destination);

		/// <summary>
		/// Return the {@code mana} of the {@code Character}. </summary>
		/// <returns>  Value of {@code mana}. </returns>
        int GetMana();

		/// <summary>
		/// Return the {@code hand} of the {@code Character}. </summary>
		/// <returns>  Obj {@code hand}. </returns>
        List<int> GetHand();

		/// <summary>
        /// Set the {@code mana} of the {@code Character}.
        /// <param name="value">     The {@code mana} value to be setted.</param>
        void SetMana(int value);

    }
}
