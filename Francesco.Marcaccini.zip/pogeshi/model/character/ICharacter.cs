using System.Collections.Generic;

namespace pogeshi.model.character
{
    public interface ICharacter
    {

        /// <summary>Return the health of the Character.</summary>
        /// <return>Value of health.</return>
        int GetHealth();

        /// <summary>Set the health of the Character.</summary>
        /// <param name="value">The health value to be setted.</param>
        void SetHealth(int value);

        /// <summary>Return a Point2D position of the Character.</summary>
        /// <return>Obj Point2D position.</return>
        IPoint2D GetPosition();

        /// <summary>Return the deck of the Character.</summary>
        /// <return>Obj Deck.</return>
        List<int> GetDeck();

        /// <summary>Return the shield of the Character.</summary>
        /// <return>Value of shield.</return>
        int GetShield();

        /// <summary>Set the shield of the Character.</summary>
        /// <param name="value">The shield value to be setted.</param>
        void SetShield(int value);

    }
}
