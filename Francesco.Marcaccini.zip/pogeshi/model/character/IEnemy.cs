namespace pogeshi.model.character
{
    public interface IEnemy : ICharacter
    {

    }
}
