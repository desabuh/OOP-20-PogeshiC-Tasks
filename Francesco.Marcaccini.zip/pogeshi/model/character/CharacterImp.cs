using System.Collections.Generic;

namespace pogeshi.model.character
{
    public class CharacterImp : ICharacter
    {

        private int health;
        private IPoint2D position;
        private List<int> deck;     //Using Deck as a List<int> to make it easier.
        private int shield;

        public CharacterImp(int health, IPoint2D position, List<int> deck, int shield)
        {
            SetHealth(health);
            SetShield(shield);
            this.position = position;
            this.deck = deck;
        }

		/// <summary>
		/// Return the value of the {@code health}.
		/// </summary>
        public int GetHealth()
        {
            return this.health;
        }

	    /// <summary>
        /// Set the {@code health} equal to the passed value.
		/// </summary>
        public void SetHealth(int value)
        {
            this.health = value;
        }

		/// <summary>
		/// Return the {@code Point2D position}.
		/// </summary>
        public IPoint2D GetPosition()
        {
            return this.position;
        }

		/// <summary>
        /// Set the {@code position} equals to the passed {@code Point2D}.
		/// </summary>
        protected void SetPosition(IPoint2D position)
        {
            this.position = position;
        }

		/// <summary>
		/// Return the {@code Deck}.
		/// </summary>
        public List<int> GetDeck()
        {
            return this.deck;
        }

		/// <summary>
		/// Return the value of the {@code shield}.
		/// </summary>
        public int GetShield()
        {
            return this.shield;
        }

		/// <summary>
        /// Set the {@code shield} equal to the passed value.
		/// </summary>
        public void SetShield(int value)
        {
            if (value < 0)
            {
                this.shield = 0;
            } else {
                this.shield = value;
            }
        }
    }
}
