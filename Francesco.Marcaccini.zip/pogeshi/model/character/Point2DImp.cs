namespace pogeshi.model.character
{
	/// <summary>
	/// immutable class to provide basic operation with 2D coordinate points, implements <seealso cref="Point2D"/>.
	/// </summary>
    public class Point2DImp : IPoint2D
    {

		/// <summary>
		/// x axis coordinate.
		/// </summary>
        private int x;

		/// <summary>
		/// y axis coordinate.
		/// </summary>
        private int y;

		/// <summary>
		/// static factory to get a new {@code Point2D} based on its coordinate. </summary>
		/// <param name="x"> </param>
		/// <param name="y"> </param>
		/// <returns> {@code Point2D} new {@code Point2D} instance  </returns>
        public static IPoint2D SetPoint(int x, int y)
        {
            return new Point2DImp(x, y);
        }

		/// <summary>
		/// static function to provide a new sum-wise Point2D. </summary>
		/// <param name="point1"> </param>
		/// <param name="point2"> </param>
		/// <returns> Point2D new Point2D instance </returns>
        public static IPoint2D SumPoint2d(IPoint2D point1, IPoint2D point2)
        {
            return SetPoint(point1.GetX() + point2.GetX(), point1.GetY() + point2.GetY());
        }

		/// <summary>
		/// Set {@code this.X} and {@code this.Y} equals to x and y. </summary>
		/// <param name="x"> </param>
		/// <param name="y"> </param>
        public Point2DImp(int x, int y)
        {
            this.x = x;
            this.y = y;
        }

		/// <summary>
		/// Return {@code X}.
		/// </summary>
        public int GetX()
        {
            return x;
        }

		/// <summary>
		/// Return {@code Y}.
		/// </summary>
        public int GetY()
        {
            return y;
        }

		/// <summary>
		/// Set {@code this.X} equal to x.
		/// </summary>
        public IPoint2D SetX(int x)
        {
            return new Point2DImp(x, this.y);
        }

		/// <summary>
		/// Set {@code this.Y} equal to y.
		/// </summary>
        public IPoint2D SetY(int y)
        {
            return new Point2DImp(this.x, y);
        }

		/// <summary>
		/// Combine in a sum two Point2D for the applied changes in respective coordinates.
		/// </summary>
        public IPoint2D Sum(int x, int y)
        {
            return SetPoint(this.GetX() + x, this.GetY() + y);
        }

        public override int GetHashCode()
        {
            const int prime = 31;
            int result = 1;
            result = prime * result + x;
            result = prime * result + y;
            return result;
        }

        public override bool Equals(object obj)
        {
            if (this == obj)
            {
                return true;
            }
            if (obj == null)
            {
                return false;
            }
            if (!(this.GetType().Equals(obj.GetType())))
            {
                return false;
            }
            Point2DImp other = (Point2DImp) obj;
            if (x != other.x)
            {
                return false;
            }
            if (y != other.y)
            {
                return false;
            }
            return true;
        }

        public override string ToString()
        {
            return "Point2DImp [x=" + x + ", y=" + y + "]";
        }

    }
}