using System.Collections.Generic;

namespace pogeshi.model.character
{
    public class EnemyImp : CharacterImp, IEnemy
    {

		/// <summary>
		/// Constructor with custom and optional parameters. </summary>
		/// <param name="deck">      The {@code deck} of the {@code enemy}. </param>
		/// <param name="health">    The {@code health} of the {@code enemy}. </param>
		/// <param name="shield">    The {@code shield} of the {@code enemy}. </param>
		/// <param name="position">  The {@code position} of the {@code enemy}. </param>
        public EnemyImp(List<int> deck, IPoint2D position, int health = 10, int shield = 0) : base(health, position, deck, shield)
        {

        }

    }
}
